using MySql.Data;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace lkpd14
{
    public partial class Form1 : Form
    {
        // Global string (menyimpan connection string untuk koneksi ke database)
        string koneksistring = "server=localhost;Database=febi;user ID=root;password=;"; // Sesuaikan dengan konfigurasi database Anda
        // Variabel global untuk koneksi
        MySqlConnection koneksi;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Kode yang dibutuhkan saat form dimuat bisa ditambahkan di sini
        }

        private bool MySqlconnect()
        {
            koneksi = new MySqlConnection(koneksistring);
            try
            {
                koneksi.Open();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal koneksi: " + ex.Message);
                return false;
            }
        }

        private void MySqldisconnect()
        {
            if (koneksi != null && koneksi.State == System.Data.ConnectionState.Open)
            {
                koneksi.Close();
            }
        }

        private void btnKoneksi_Click(object sender, EventArgs e)
        {
            koneksi = new MySqlConnection(koneksistring);
            try
            {
                koneksi.Open();
                MessageBox.Show("Koneksi dengan MySQL berhasil!");
                koneksi.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal koneksi: " + ex.Message);
            }
        }

        private void btnTampil_Click(object sender, EventArgs e)
        {
            // Bersihkan DataGridView untuk menghindari data duplikat
            dataGridView1.DataSource = null;

            if (MySqlconnect())
            {
                string query = "SELECT * FROM barang";
                try
                {
                    MySqlCommand cmd = new MySqlCommand(query, koneksi);
                    //MySqlDataReader reader = cmd.ExecuteReader();
                    //while (reader.Read())
                    //{
                    //    dataGridView1.Rows.Add(
                    //        reader.GetInt32(0), // id_barang
                    //        reader.GetString(1), // nama_barang
                    //        reader.GetInt32(2), // berat_barang
                    //        reader.GetInt32(3), // harga_barang
                    //        reader.GetDateTime(4).ToString("yyyy-MM-dd HH:mm:ss"), // tglmasuk_barang
                    //        reader.GetDateTime(5).ToString("yyyy-MM-dd HH:mm:ss")  // tgledit_barang
                    //    );
                    //}
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataSet dataSet = new DataSet();

                    da.Fill(dataSet);
                    dataGridView1.DataSource = dataSet.Tables[0];
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saat mengambil data: " + ex.Message);
                }
                finally
                {
                    MySqldisconnect();
                }
            }
        }

        private void btnTambah_Click(object sender, EventArgs e)
        {
            string getnama = txtNamabarang.Text;
            uint getberat;
            uint getharga;

            // Validasi input
            if (string.IsNullOrWhiteSpace(getnama) || !uint.TryParse(txtBeratbarang.Text, out getberat) || !uint.TryParse(txtHargabarang.Text, out getharga))
            {
                MessageBox.Show("Input tidak valid. Pastikan semua kolom terisi dengan benar.");
                return;
            }

            if (MySqlconnect())
            {
                string query = "INSERT INTO barang (nama_barang, berat_barang, harga_barang, tglmasuk_barang, tgledit_barang) VALUES (@nama, @berat, @harga, @tglmasuk, @tgledit)";
                try
                {
                    var cmd = new MySqlCommand(query, koneksi);
                    cmd.Parameters.AddWithValue("@nama", getnama);
                    cmd.Parameters.AddWithValue("@berat", getberat);
                    cmd.Parameters.AddWithValue("@harga", getharga);
                    cmd.Parameters.AddWithValue("@tglmasuk", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    cmd.Parameters.AddWithValue("@tgledit", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show($"Data berhasil ditambahkan. {rowsAffected} baris terpengaruh.");
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error saat menambahkan data: " + ex.Message);
                }
                finally
                {
                    MySqldisconnect();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Bersihkan semua input dan DataGridView
            dataGridView1.Rows.Clear();
            txtNamabarang.Clear();
            txtBeratbarang.Clear();
            txtHargabarang.Clear();
            MessageBox.Show("Form telah dibersihkan.");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Apakah Anda yakin ingin keluar?", "Konfirmasi Keluar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih item dari daftar untuk diperbarui.");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            uint id_barang = Convert.ToUInt32(selectedRow.Cells[0].Value);
            string getnama = txtNamabarang.Text;
            uint getberat;
            uint getharga;

            if (string.IsNullOrWhiteSpace(getnama) || !uint.TryParse(txtBeratbarang.Text, out getberat) || !uint.TryParse(txtHargabarang.Text, out getharga))
            {
                MessageBox.Show("Input tidak valid. Pastikan semua kolom terisi dengan benar.");
                return;
            }

            if (MySqlconnect())
            {
                string query = "UPDATE barang SET nama_barang = @nama, berat_barang = @berat, harga_barang = @harga, tgledit_barang = @tgledit WHERE id_barang = @id";
                try
                {
                    var cmd = new MySqlCommand(query, koneksi);
                    cmd.Parameters.AddWithValue("@id", id_barang);
                    cmd.Parameters.AddWithValue("@nama", getnama);
                    cmd.Parameters.AddWithValue("@berat", getberat);
                    cmd.Parameters.AddWithValue("@harga", getharga);
                    cmd.Parameters.AddWithValue("@tgledit", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data berhasil diperbarui.");
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    MySqldisconnect();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih item dari daftar untuk dihapus.");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            uint id_barang = Convert.ToUInt32(selectedRow.Cells[0].Value);

            var result = MessageBox.Show("Apakah Anda yakin ingin menghapus data ini?", "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                if (MySqlconnect())
                {
                    string query = "DELETE FROM barang WHERE id_barang = @id";
                    try
                    {
                        var cmd = new MySqlCommand(query, koneksi);
                        cmd.Parameters.AddWithValue("@id", id_barang);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Data berhasil dihapus.");
                        btnTampil_Click(sender, e); // Refresh list
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        MySqldisconnect();
                    }
                }
            }
        }
    }
}