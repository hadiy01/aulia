﻿namespace lkpd14
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            groupBox1 = new GroupBox();
            button5 = new Button();
            txtHargabarang = new TextBox();
            txtBeratbarang = new TextBox();
            txtNamabarang = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            button6 = new Button();
            button7 = new Button();
            dataGridView1 = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Modern No. 20", 15.9999981F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(358, 89);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(508, 34);
            label1.TabIndex = 0;
            label1.Text = "DATA BARANG AULIA's STORE";
            // 
            // button1
            // 
            button1.Location = new Point(150, 167);
            button1.Margin = new Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new Size(183, 38);
            button1.TabIndex = 1;
            button1.Text = "Cek Koneksi Mysql";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnKoneksi_Click;
            // 
            // button2
            // 
            button2.Location = new Point(370, 167);
            button2.Margin = new Padding(4, 5, 4, 5);
            button2.Name = "button2";
            button2.Size = new Size(183, 38);
            button2.TabIndex = 2;
            button2.Text = "Tampilkan Data";
            button2.UseVisualStyleBackColor = true;
            button2.Click += btnTampil_Click;
            // 
            // button3
            // 
            button3.Location = new Point(607, 167);
            button3.Margin = new Padding(4, 5, 4, 5);
            button3.Name = "button3";
            button3.Size = new Size(130, 38);
            button3.TabIndex = 3;
            button3.Text = "CLEAR";
            button3.UseVisualStyleBackColor = true;
            button3.Click += btnClear_Click;
            // 
            // button4
            // 
            button4.Location = new Point(796, 167);
            button4.Margin = new Padding(4, 5, 4, 5);
            button4.Name = "button4";
            button4.Size = new Size(130, 38);
            button4.TabIndex = 4;
            button4.Text = "EXIT";
            button4.UseVisualStyleBackColor = true;
            button4.Click += btnExit_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(txtHargabarang);
            groupBox1.Controls.Add(txtBeratbarang);
            groupBox1.Controls.Add(txtNamabarang);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new Point(150, 508);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(467, 222);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tambah Barang";
            // 
            // button5
            // 
            button5.Location = new Point(351, 50);
            button5.Margin = new Padding(4, 5, 4, 5);
            button5.Name = "button5";
            button5.Size = new Size(107, 148);
            button5.TabIndex = 6;
            button5.Text = "TAMBAH";
            button5.UseVisualStyleBackColor = true;
            button5.Click += btnTambah_Click;
            // 
            // txtHargabarang
            // 
            txtHargabarang.Location = new Point(130, 168);
            txtHargabarang.Margin = new Padding(4, 5, 4, 5);
            txtHargabarang.Name = "txtHargabarang";
            txtHargabarang.Size = new Size(193, 31);
            txtHargabarang.TabIndex = 5;
            // 
            // txtBeratbarang
            // 
            txtBeratbarang.Location = new Point(130, 110);
            txtBeratbarang.Margin = new Padding(4, 5, 4, 5);
            txtBeratbarang.Name = "txtBeratbarang";
            txtBeratbarang.Size = new Size(193, 31);
            txtBeratbarang.TabIndex = 4;
            // 
            // txtNamabarang
            // 
            txtNamabarang.Location = new Point(130, 50);
            txtNamabarang.Margin = new Padding(4, 5, 4, 5);
            txtNamabarang.Name = "txtNamabarang";
            txtNamabarang.Size = new Size(193, 31);
            txtNamabarang.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 173);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(120, 25);
            label4.TabIndex = 2;
            label4.Text = "Harga Barang";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 110);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(127, 25);
            label3.TabIndex = 1;
            label3.Text = "Jumlah Barang";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 50);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(119, 25);
            label2.TabIndex = 0;
            label2.Text = "Nama Barang";
            // 
            // button6
            // 
            button6.Location = new Point(663, 577);
            button6.Margin = new Padding(4, 5, 4, 5);
            button6.Name = "button6";
            button6.Size = new Size(107, 67);
            button6.TabIndex = 7;
            button6.Text = "UPDATE";
            button6.UseVisualStyleBackColor = true;
            button6.Click += btnUpdate_Click;
            // 
            // button7
            // 
            button7.Location = new Point(830, 577);
            button7.Margin = new Padding(4, 5, 4, 5);
            button7.Name = "button7";
            button7.Size = new Size(107, 67);
            button7.TabIndex = 8;
            button7.Text = "DELETE";
            button7.UseVisualStyleBackColor = true;
            button7.Click += btnDelete_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(82, 228);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(946, 260);
            dataGridView1.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkSlateBlue;
            ClientSize = new Size(1143, 750);
            Controls.Add(dataGridView1);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(groupBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private GroupBox groupBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button button5;
        private TextBox txtHargabarang;
        private TextBox txtBeratbarang;
        private TextBox txtNamabarang;
        private Button button6;
        private Button button7;
        private DataGridView dataGridView1;
    }
}
